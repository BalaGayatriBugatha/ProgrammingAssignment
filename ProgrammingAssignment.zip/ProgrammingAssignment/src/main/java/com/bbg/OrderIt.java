package com.bbg;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.*;


public class OrderIt extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String s=(String)request.getParameter("word");
		Map<Character, Integer> counts = new TreeMap<>();
	    for (char c : s.toCharArray()) {
	        counts.put(c, counts.getOrDefault(c, 0) + 1);
	    }
	            
	    
	    ArrayList<Character> characters = new ArrayList<>(counts.keySet());        
	    Collections.sort(characters, (a, b) -> counts.get(b) - counts.get(a));

	    
	    StringBuilder sb = new StringBuilder();
	    for (char c : characters) {
	        int copies = counts.get(c);
	        for (int i = 0; i < copies; i++) {
	            sb.append(c);
	        }
	    }
	    HttpSession session=request.getSession();
	    		
	    session.setAttribute("new_word",sb.reverse().toString());
	    response.sendRedirect("Result.jsp");
		
	}

	

}
